<?php
$mod_strings["LBL_ELASTIC_SEARCH_STATS"] = "Index Stats";
