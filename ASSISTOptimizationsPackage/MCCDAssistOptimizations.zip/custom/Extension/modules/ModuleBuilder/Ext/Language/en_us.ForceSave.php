<?php
$mod_strings['LBL_BTN_SAVEPUBLISH_FORCE'] = 'Save & Force Deploy';
