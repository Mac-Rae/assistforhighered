# Maricopa Community Colleges Optimization Package
- Jim Mackin - jim.mackin@salesagility.com
- V1

## Introduction
This package contains some optimizations for the ASSIST instance.

## Changes

- Adds a custom contact list view to override the name sorting to use the more sensible last_name, first_name for sorting. This considerably improves sorting performance.
