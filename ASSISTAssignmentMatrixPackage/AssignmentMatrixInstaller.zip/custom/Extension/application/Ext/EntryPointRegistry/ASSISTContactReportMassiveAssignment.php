<?php
$entry_point_registry['ASSISTMassiveAssign'] = array(
    'file' => 'custom/include/Services/ASSISTAssignment/MassiveAssignFromReportEntryPoint.php',
    'auth' => true,
);