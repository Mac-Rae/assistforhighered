<?php
$entry_point_registry['ASSISTAssignToMe'] = array(
    'file' => 'custom/include/Services/ASSISTAssignment/AssignToMeEntryPoint.php',
    'auth' => true,
);