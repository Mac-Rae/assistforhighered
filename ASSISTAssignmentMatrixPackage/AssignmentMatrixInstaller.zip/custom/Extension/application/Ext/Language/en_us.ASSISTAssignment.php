<?php
$app_strings['LBL_ASSIST_ASSIGNMENT_ASSIGN_TO_ME'] = 'Assign To Me';
$app_strings['LBL_ASSIST_ASSIGN_TO_ME_ERROR'] = 'Failed to assign this record.';
$app_strings['LBL_ASSIST_ASSIGN_TO_ME_SUCCESS'] = 'Successfully assigned this record.';

$app_strings['LBL_ASSIST_MASSIVE_ASSIGN_TO_USER_ERROR'] = 'Failed to assign contacts from report.';
$app_strings['LBL_ASSIST_MASSIVE_ASSIGN_TO_USER_SUCCESS'] = 'Successfully queued assigning all contacts from the report. Changes should take effect within the next 10 minutes.';
