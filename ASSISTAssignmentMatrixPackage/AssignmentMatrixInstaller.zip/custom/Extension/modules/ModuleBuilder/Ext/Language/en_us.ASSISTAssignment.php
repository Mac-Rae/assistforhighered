<?php
$mod_strings['fieldTypes']['ASSISTAssignment'] = 'Assignment Matrix';
