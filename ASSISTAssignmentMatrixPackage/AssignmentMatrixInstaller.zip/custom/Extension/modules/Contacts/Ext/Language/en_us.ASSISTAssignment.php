<?php
$mod_strings['LBL_ASSIST_ADVISOR_PANEL'] = 'Advisors';
$mod_strings['LBL_CHANDLER_USER'] = 'Chandler';
$mod_strings['LBL_ESTRELLA_MOUNTAIN_USER'] = 'Estrella Mountain';
$mod_strings['LBL_GATEWAY_USER'] = 'Gateway';
$mod_strings['LBL_GLENDALE_USER'] = 'Glendale';
$mod_strings['LBL_MESA_USER'] = 'Mesa';
$mod_strings['LBL_PARADISE_VALLEY_USER'] = 'Paradise Valley';
$mod_strings['LBL_PHOENIX_USER'] = 'Phoenix';
$mod_strings['LBL_RIO_SALADO_USER'] = 'Rio Salado';
$mod_strings['LBL_SCOTTSDALE_USER'] = 'Scottsdale';
$mod_strings['LBL_SOUTH_MOUNTAIN_USER'] = 'South Mountain';
$mod_strings['LBL_DISTRICT_USER'] = 'District';
$mod_strings['LBL_MY_STUDENTS_FILTER'] = 'My Students';