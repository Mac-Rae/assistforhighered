<?php
$hook_array['after_retrieve'][] = array(
    0,
    'Load ASSIST Assignment Fields',
    'custom/include/SugarFields/Fields/ASSISTAssignment/ASSISTAssignmentLogicHooks.php',
    'ASSISTAssignmentLogicHooks',
    'loadAssignmentFields');
