<?php
$mod_strings['LBL_ASSIGN_TO_ADVISOR'] = 'Assign to Advisor';