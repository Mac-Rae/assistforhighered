<?php
// created: 2021-03-09 15:32:57
$dictionary["SA_Institutions"]["fields"]["sa_institutions_leads"] = array (
  'name' => 'sa_institutions_leads',
  'type' => 'link',
  'relationship' => 'sa_institutions_leads',
  'source' => 'non-db',
  'module' => 'Leads',
  'bean_name' => 'Lead',
  'vname' => 'LBL_SA_INSTITUTIONS_LEADS_FROM_LEADS_TITLE',
);
