<?php
// created: 2021-03-09 15:32:57
$dictionary["SA_Institutions"]["fields"]["sa_institutions_prospects"] = array (
  'name' => 'sa_institutions_prospects',
  'type' => 'link',
  'relationship' => 'sa_institutions_prospects',
  'source' => 'non-db',
  'module' => 'Prospects',
  'bean_name' => 'Prospect',
  'vname' => 'LBL_SA_INSTITUTIONS_PROSPECTS_FROM_PROSPECTS_TITLE',
);
