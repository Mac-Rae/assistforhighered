<?php
// created: 2021-03-09 15:32:57
$dictionary["Prospect"]["fields"]["sa_institutions_prospects"] = array (
  'name' => 'sa_institutions_prospects',
  'type' => 'link',
  'relationship' => 'sa_institutions_prospects',
  'source' => 'non-db',
  'module' => 'SA_Institutions',
  'bean_name' => false,
  'vname' => 'LBL_SA_INSTITUTIONS_PROSPECTS_FROM_SA_INSTITUTIONS_TITLE',
);
