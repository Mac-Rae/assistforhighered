<?php
// created: 2021-03-09 15:32:57
$dictionary["Contact"]["fields"]["sa_institutions_contacts"] = array (
  'name' => 'sa_institutions_contacts',
  'type' => 'link',
  'relationship' => 'sa_institutions_contacts',
  'source' => 'non-db',
  'module' => 'SA_Institutions',
  'bean_name' => false,
  'vname' => 'LBL_SA_INSTITUTIONS_CONTACTS_FROM_SA_INSTITUTIONS_TITLE',
);
