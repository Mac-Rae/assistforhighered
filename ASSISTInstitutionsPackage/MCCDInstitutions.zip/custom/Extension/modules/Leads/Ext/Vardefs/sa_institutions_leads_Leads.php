<?php
// created: 2021-03-09 15:32:57
$dictionary["Lead"]["fields"]["sa_institutions_leads"] = array (
  'name' => 'sa_institutions_leads',
  'type' => 'link',
  'relationship' => 'sa_institutions_leads',
  'source' => 'non-db',
  'module' => 'SA_Institutions',
  'bean_name' => false,
  'vname' => 'LBL_SA_INSTITUTIONS_LEADS_FROM_SA_INSTITUTIONS_TITLE',
);
