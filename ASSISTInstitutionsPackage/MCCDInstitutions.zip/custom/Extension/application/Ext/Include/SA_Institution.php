<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['SA_Institutions'] = 'SA_Institutions';
$beanFiles['SA_Institutions'] = 'modules/SA_Institutions/SA_Institutions.php';
$moduleList[] = 'SA_Institutions';

?>