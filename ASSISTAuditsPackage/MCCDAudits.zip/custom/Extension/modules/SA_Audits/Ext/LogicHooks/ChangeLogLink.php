<?php
$hook_array['process_record'][] = [1,'Add the Change Log Link to the list view','modules/SA_Audits/SA_Audits.php','SA_Audits','addChangeLogLink'];
