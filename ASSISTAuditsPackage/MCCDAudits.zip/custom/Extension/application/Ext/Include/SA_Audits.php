<?php

$beanList['SA_Audits'] = 'SA_Audits';
$beanFiles['SA_Audits'] = 'modules/SA_Audits/SA_Audits.php';
$moduleList[] = 'SA_Audits';
