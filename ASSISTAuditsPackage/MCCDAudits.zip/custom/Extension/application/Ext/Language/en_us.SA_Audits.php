<?php
$app_list_strings['moduleList']['SA_Audits'] = 'User Activity Audits';
$app_list_strings['moduleListSingular']['SA_Audits'] = 'User Activity Audit';
